#how to use
just run sh start.sh is find
!!!!!!!depends:curl!!!!
