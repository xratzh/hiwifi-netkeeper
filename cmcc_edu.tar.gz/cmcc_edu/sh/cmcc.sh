#!/bin/sh
#把帐号和密码添上，然后运行脚本即可登录。
username=""
passwd=""
user_agent="Mozilla/5.0 (X11; Linux x86_64; rv:50.0) Gecko/20100101 Firefox/50.0"
curl -A $"user_agent" www.google.com > index.html
show_login=$(cat index.html |grep NextURL | awk -F '<' '{printf $2}'| cut -c 9-58)
login_data=$(cat index.html |grep NextURL | awk -F '<' '{printf $2}'| cut -c 60-)
NextUrl=$(cat index.html |grep NextURL | awk -F '<' '{printf $2}'| cut -c 9-)
#wget -U "${user_agent}" --keep-session-cookies --save-cookies=cookie.text "${NextUrl}" --header="Accept-Encoding:deflate" \
#--header="Accept-Language:en-US,en;q=0.5" --header="Content-Type: application/x-www-form-urlencoded" -O login_pre.html
curl -k -A "${user_agent}" -c cookie.text "${show_login}" -d "${login_data}" -H "Accept-Encoding: deflate" -H "Accept-Language:en-US,en;q=0.5" \
-H "Content-Type: application/x-www-form-urlencoded" > pre.html
#cook=$(cat cookie.text |grep Cookie |awk '{printf $7}')
#JSE=$(cat cookie.text |grep JSESSIONID |awk '{printf $7}')
login_url=$(cat pre.html |grep loginForm |awk -F '"' '{printf $4}')
#wget -U "${user_agent}" --load-cookies=cookie.text --keep-session-cookies "${NextUrl}" --no-check-certificate --header="Accept-Encoding: deflate" \
#--header="Accept-Language:en-US,en;q=0.5" --header="Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" -O login_pre.1.html
#CSRFToken_HW=$(cat login_pre.1.html |grep CSRFToken_HW |awk  '{printf $4}' |cut -c 8-39)
#wget -d -U "${user_agent}" --load-cookies=cookie.text --header="Accept-Encoding:deflate" \
#--header="Content-Type: application/x-www-form-urlencoded" --no-check-certificate --save-cookies=cookie.text --header="Accept-Language:en-US,en;q=0.5" \
#--header="Upgrade-Insecure-Requests: 1" --header="Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" --referer="${NextUrl}" -t1 \
#--no-dns-cache --save-headers --header="Cookies: JSESSIONID=$JSE; Cookie_Persist=$cook" --no-cache --auth-no-challenge \
#--post-data="bpssUSERNAME="$username"&bpssBUSPWD="$passwd "${login_url}" --keep-session-cookies -O login_res.html
curl -k -A "${user_agent}" -c cookie.text -b cookie.text -d "bpssUSERNAME=$username&bpssBUSPWD=$passwd"  -e "${NextUrl}" \
-H "Content-Type: application/x-www-form-urlencoded" -H "Accept-Encoding: deflate" -H "Accept-Language:en-US,en;q=0.5" "${login_url}" > aut.html
if [ "$(cat aut.html| grep logout.do)" ]
then echo "login successful! ^_^"
else 
echo "login fail! please try again! T_T"
echo "$(cat aut.html | grep alert |awk -F '"' '{printf $2}')"
fi
