#!/bin/sh
do_url=$(cat aut.html | grep logout |sed -n '3p' |awk -F '"' '{printf $2}'| cut -c -10)
base_url=$(cat pre.html |grep loginForm |awk -F '"' '{printf $4}' |head -c 38)
logout_url="${base_url}""${do_url}"
data=$(cat aut.html | grep logout |sed -n '3p' |awk -F '"' '{printf $2 $3 $4}'| cut -c 12-)

echo "${logout_url}"
curl  -A "Mozilla/5.0 (X11; Linux x86_64; rv:50.0) Gecko/20100101 Firefox/50.0" -d "${data}"-H "Accept-Encoding: deflate" \
-H "Accept-Language:en-US,en;q=0.5" "${logout_url}" \
-H "Content-Type: application/x-www-form-urlencoded" -c cookie.text -b cookie.text > out.html
if [ $(cat out.html | grep SUCCESS) ]
then echo "logout success"
else echo "failed"
fi
