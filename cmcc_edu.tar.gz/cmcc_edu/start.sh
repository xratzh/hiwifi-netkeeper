#!/bin/sh
if [ ! -n "$(cat sh/cmcc.sh | grep username= |awk -F '"' '{printf $2}')" ]
then
echo "please input your username and passwd"
read -p "cmcc-username:" username
sed -i "s/username=\"\"/username=\"$username\"/g" sh/cmcc.sh
read -p  "cmcc-passwd:" passwd
sed -i "s/passwd=\"\"/passwd=\"$passwd\"/g" sh/cmcc.sh
else
read -p "could you wanto to change username and passwd? y/n:" rel
if [ "$rel" = "y" ]
then
echo "please input your username and passwd"
usr=$(cat sh/cmcc.sh | grep username= |awk -F '"' '{printf $2}')
pwd=$(cat sh/cmcc.sh | grep passwd= |awk -F '"' '{printf $2}')
read -p "cmcc-username:" username
sed -i "s/username=\"$usr\"/username=\"$username\"/g" sh/cmcc.sh
read -p  "cmcc-passwd:" passwd
sed -i "s/passwd=\"$pwd\"/passwd=\"$passwd\"/g" sh/cmcc.sh
elif [ "$rel" = "n" ]
then
echo "using exiting username and passwd to connect"
else echo "please input "y" or "n"!"
exit 0
fi 
fi
read -p "input login to login; input logout to logout:"  cmd
if [ "$cmd" = "login" ]; then
cd data
sh ../sh/cmcc.sh
elif [ "$cmd" = "logout" ]; then
cd data
sh ../sh/cmcc.out.sh
else 
echo "error! no such command!"
exit 0
fi
exit 0
